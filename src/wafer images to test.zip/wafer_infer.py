import os, numpy as np, torch, torch.nn as nn, joblib, timm, cv2

BACKBONES = {'dino': ('vit_base_patch14_dinov2.lvd142m', dict(img_size=224)),
             'vit':  ('vit_base_patch16_224.augreg_in21k_ft_in1k', {})}

def to_img(m):  # same preprocessing as training
    return cv2.resize(np.asarray(m).astype(np.uint8) * 127, (224, 224), interpolation=cv2.INTER_NEAREST)

class WaferModel:
    def __init__(self, folder='.', ds='wm', device=None):
        self.dev = device or ('cuda' if torch.cuda.is_available() else 'cpu')
        self.dt = torch.float16 if self.dev == 'cuda' else torch.float32
        ck = torch.load(os.path.join(folder, f'classifier_mlp_{ds}_full.pt'), map_location='cpu', weights_only=False)
        pp = joblib.load(os.path.join(folder, f'classifier_mlp_{ds}_full_prep.joblib'))
        self.det = joblib.load(os.path.join(folder, f'detector_{ds}_full_dino+vit.joblib'))
        self.classes, self.tags, self.scaler = list(ck['classes']), pp['tags'], pp['scaler']
        self.normal = 'none' if 'none' in self.classes else '00000000'
        self.net = nn.Sequential(nn.Linear(ck['in_dim'], 512), nn.GELU(), nn.Dropout(0.3),
                                 nn.Linear(512, len(self.classes)))
        self.net.load_state_dict(ck['state']); self.net.eval()
        self.models = {}
        for t in set(self.tags) | set(self.det['tags']):
            name, kw = BACKBONES[t]
            self.models[t] = timm.create_model(name, pretrained=True, num_classes=0, **kw).to(self.dev).eval().to(self.dt)
        self.mean = torch.tensor([0.485, 0.456, 0.406], device=self.dev).view(1, 3, 1, 1)
        self.std = torch.tensor([0.229, 0.224, 0.225], device=self.dev).view(1, 3, 1, 1)

    @torch.no_grad()
    def embed(self, maps, bs=64):
        out = {t: [] for t in self.models}
        for i in range(0, len(maps), bs):
            x = torch.from_numpy(np.stack([to_img(m) for m in maps[i:i+bs]])).to(self.dev).float() / 254.0
            x = ((x[:, None].repeat(1, 3, 1, 1) - self.mean) / self.std).to(self.dt)
            for t, m in self.models.items(): out[t].append(m(x).float().cpu().numpy())
        return {t: np.concatenate(v) for t, v in out.items()}

    def predict(self, maps):
        if isinstance(maps, np.ndarray) and maps.ndim == 2: maps = [maps]
        E = self.embed(list(maps))
        X = self.scaler.transform(np.hstack([E[t] for t in self.tags])).astype(np.float32)
        with torch.no_grad(): P = torch.softmax(self.net(torch.tensor(X)), 1).numpy()
        d = self.det
        Z = np.hstack([sc.transform(E[t]) / np.sqrt(E[t].shape[1]) for t, sc in zip(d['tags'], d['scalers'])])
        s_det = -d['iso'].score_samples(d['pca'].transform(Z))
        ni = self.classes.index(self.normal)
        res = []
        for p, s in zip(P, s_det):
            top = np.argsort(-p)[:3]
            res.append(dict(label=self.classes[top[0]], confidence=round(float(p[top[0]]), 4),
                            top3={self.classes[j]: round(float(p[j]), 4) for j in top},
                            anomaly_score_classifier=round(float(1 - p[ni]), 4),
                            detector_score=round(float(s), 4)))
        return res
